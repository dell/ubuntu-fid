#define UTS_RELEASE "2.6.27-10-generic"
