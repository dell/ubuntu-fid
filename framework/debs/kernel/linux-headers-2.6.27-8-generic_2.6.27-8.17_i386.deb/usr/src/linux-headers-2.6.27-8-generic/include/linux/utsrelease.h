#define UTS_RELEASE "2.6.27-8-generic"
