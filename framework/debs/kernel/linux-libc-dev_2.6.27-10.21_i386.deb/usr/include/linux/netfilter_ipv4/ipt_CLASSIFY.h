#ifndef _IPT_CLASSIFY_H
#define _IPT_CLASSIFY_H

#include <linux/netfilter/xt_CLASSIFY.h>
#define ipt_classify_target_info xt_classify_target_info

#endif /*_IPT_CLASSIFY_H */
