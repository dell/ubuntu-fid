#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# «dell-eula» - Presents a HW EULA to the user
#
# Copyright (C) 2010, Dell Inc.
#
# Author:
#  - Mario Limonciello <Mario_Limonciello@Dell.com>

from ubiquity.plugin import *
import os
import glob

NAME = 'dell-eula'
AFTER = 'language'
BEFORE = 'timezone'
WEIGHT = 12

#Map of Ubuntu language to Dell EULA representation
#of that language
MAP = {
        'cs'    : 'EN', #Map Cestina to english since this needs to be simplified chinese
        'zh_CN' : 'CS', #simplified chinese
        'zh_TW' : 'CT', #complex chinese
        'pl'    : 'PO', #polish
      }

EULA_DIRECTORY = '/usr/share/dell/eula/'

class PageGtk(PluginUI):
    def __init__(self, controller, *args, **kwargs):
        self.plugin_widgets = None
        self.controller = controller
        if 'UBIQUITY_OEM_USER_CONFIG' in os.environ:
            import gtk
            builder = gtk.Builder()
            builder.add_from_file('/usr/share/ubiquity/gtk/stepDellEULA.ui')
            builder.connect_signals(self)
            self.controller.add_builder(builder)
            self.genuine_box = builder.get_object('genuine_box')
            self.accept_button = builder.get_object('accept_button')
            self.debug = builder.get_object('debug')
            eula_frame = builder.get_object('eula_frame')

            import webkit
            self.webview = webkit.WebView()
            s = self.webview.get_settings()
            s.set_property('enable-file-access-from-file-uris', True)
            s.set_property('enable-default-context-menu', False)            
            eula_frame.add(self.webview)
            eula_frame.show_all()

            #load the initial EULA page
            self.plugin_translate('C')

            if 'UBIQUITY_DEBUG' in os.environ:
                self.debug.show()

            self.plugin_widgets = builder.get_object('stepDellEULA')

    def plugin_translate(self, lang):
        #try to map it do a dell language if possible
        if lang in MAP:
            lang = MAP[lang]

        text = 'file://'
        #check if we support this langauge
        file = glob.glob(EULA_DIRECTORY + '*_%s.html' % lang.upper())
        if file:
            text += file[0]
        #We're guaranteed to have english
        else:
            text += EULA_DIRECTORY + 'Dell_Eula.html'
        self.webview.open(text)

        #for helping to debug when a language isn't showing up
        self.debug.set_text(lang)
        
    def plugin_get_current_page(self):
        #If we have dell-recovery installed, we can check the vendor
        try:
            import Dell.recovery_common as magic
            if not magic.check_vendor():
                self.genuine_box.show()
                self.accept_button.set_sensitive(False)
        except ImportError:
            pass
        self.controller.allow_go_forward(False)
        return self.plugin_widgets

    def accept_toggled(self, widget):
        self.controller.allow_go_forward(widget.get_active())
