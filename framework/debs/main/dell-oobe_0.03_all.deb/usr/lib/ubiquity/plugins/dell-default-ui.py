#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# «dell-default-ui»
#
# OEM Config plugin for Setting Default Desktop UI
#
# Attempts to set to UDE if available and correct LOB
#
# Copyright (C) 2010, Dell Inc.
#
# Author:
#  - Mario Limonciello <Mario_Limonciello@Dell.com>

import sys
import subprocess
import math
import os
try:
    from ubiquity.plugin import *
except ImportError:
    sys.path.insert(0, '/usr/lib/ubiquity/')
    from ubiquity.plugin import *

NAME = 'dell-default-ui'
AFTER = 'usersetup'
BEFORE = None
WEIGHT = 12

class Install(InstallPlugin):

    def debug(self, string):
        """Allows the plugin to be ran standalone"""
        if self.target == '__main__':
            print string
        else:
            InstallPlugin.debug(string)
            
    def install(self, target, progress, *args, **kwargs):
        if not 'UBIQUITY_OEM_USER_CONFIG' in os.environ:
            return InstallPlugin.install(self, target, progress, *args, **kwargs)

        self.target = target
        BIZ_CLIENT  = [ 'latitude',
                        'optiplex',
                        'vostro',
                        'precision',
                      ]

        with open('/sys/class/dmi/id/product_name','r') as dmi:
            lob = dmi.readline().lower().split()[0]

        #Make sure UDE is available and LOB matches
        if os.path.exists('/usr/share/xsessions/gnome.desktop') and lob in BIZ_CLIENT:
            self.debug("%s: LOB %s matched." % (NAME,lob))
            ## check for large enough display (1024x768)##
            MIN_X = 1366
            MIN_Y = 768

            try:
                import gtk.gdk
            except ImportError:
                self.debug("%s: Error importing gtk to find screen dimensions." % NAME)
                return

            x = gtk.gdk.screen_width()
            y = gtk.gdk.screen_height()

            if x > MIN_X and y > MIN_Y:
                self.debug("%s: %ix%i >= %ix%i, setting default session." % (NAME, x, y, MIN_X, MIN_Y))
                if os.path.exists('/usr/lib/gdm/gdm-set-default-session'):
                    subprocess.call(['/usr/lib/gdm/gdm-set-default-session', 'gnome'])
                else:
                    self.debug("%s: Unable to set default session, gdm-set-default-session not on system.")
            else:
                self.debug("%s: %ix%i < %ix%i, leaving default session." % (NAME, x, y, MIN_X, MIN_Y))
        else:
            self.debug("%s: LOB %s didn't match." % (NAME,lob))

if __name__ == '__main__':
    install = Install(None, None)
    install.install( __name__, None)
