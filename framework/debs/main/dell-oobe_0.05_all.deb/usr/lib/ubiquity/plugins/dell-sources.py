#!/usr/bin/python
# -*- coding: utf-8 -*-
#
# «dell-sources»
#
# Prepares the sources.list based on LOB
#
# Copyright (C) 2010, Dell Inc.
#
# Author:
#  - Mario Limonciello <Mario_Limonciello@Dell.com>

import sys
import os
import textwrap
import lsb_release
import hashlib
import subprocess
import debconf
import shutil

try:
    from ubiquity.plugin import *
    from ubiquity.misc import create_bool
except ImportError:
    sys.path.insert(0, '/usr/lib/ubiquity/')
    from ubiquity.plugin import *
    from ubiquity.misc import create_bool

NAME = 'dell-sources'
AFTER = 'dell-default-ui'
BEFORE = None
WEIGHT = 12

KEYRING = '/usr/share/keyrings/canonical-oem-archive-keyring.gpg'

class Install(InstallPlugin):

    def debug(self, string):
        """Allows the plugin to be ran standalone"""
        if self.target == '__main__':
            print string
        else:
            InstallPlugin.debug(string)

    def write_source(self, source):
        """Writes a sources.list out"""
        
        codename = lsb_release.get_distro_information()['CODENAME']

        self.debug("%s: selected source: %s" % (NAME, source))
        output = textwrap.dedent("""\
            # This APT source is included for tracking the stickiness of Ubuntu by counting
            # your factory shipped machine. Getting an accurate representation of factory
            # shipped machines helps to calculate demand and appropriately allocate
            # resources to future developments.
            #
            # If you don't want to be included in the count, you can safely remove this file
            # and your machine will continue to operate as it would normally.
            #
            # You can read additional details about this effort at:
            # http://en.community.dell.com/support-forums/software-os/w/linux/stickiness.aspx
            deb http://%s/updates/ %s-dell public
            """ % (source, codename))

        if self.target == '__main__':
            self.debug("%s: Outputing dell.list to stdout" % NAME)
            print output
        else:
            self.debug("%s: Outputting to /etc/apt/sources.list.d/dell-tracking.list" % NAME)
            with open ('/etc/apt/sources.list.d/dell-tracking.list', 'w') as wfd:
                print >>wfd, output

    def enable_upgrades(self, source):
        '''Sets up some magic to make sure update-manager keeps the mirror on during upgrades'''

        self.debug("%s: producing /etc/update-manager/release-upgrades.d/dell.cfg to fix upgrades" % NAME)

        output = textwrap.dedent("""\
            [Sources]
            Pockets=security,updates,backports,proposed,dell
            ValidMirrors=/usr/share/dell/mirrors.txt
            """)

        source_url = "http://%s/updates/" % source

        if self.target == '__main__':
            self.debug("%s: Outputing dell.cfg to stdout" % NAME)
            print output

            self.debug("%s: Outputting appendation to stdout" % NAME)
            print source_url
        else:
            #config to use custom mirror location
            with open('/etc/update-manager/release-upgrades.d/dell.cfg', 'w') as wfd:
                print >> wfd, output

            #custom mirrors list
            shutil.copy('/usr/share/update-manager/mirrors.cfg', '/usr/share/dell/mirrors.txt')
            with open('/usr/share/dell/mirrors.txt','a') as afd:
                print >>afd, source_url
    
    def install(self, target, progress, *args, **kwargs):
        if not 'UBIQUITY_OEM_USER_CONFIG' in os.environ:
            return InstallPlugin.install(self, target, progress, *args, **kwargs)

        self.target = target

        POSSIBLE_LOB  = { 'latitude':   'latitude',
                          'optiplex':   'optiplex',
                          'vostro':     'vostro',
                          'precision':  'precision',
                          'inspiron':   'inspiron',
                          'studio':     'studio',
                          'studio xps': 'studioxps',
                          'adamo':      'adamo',
                        }

        #Whether we actually run this plugin
        enable = False
        try:
            enable = create_bool(progress.get('dell-oobe/tracking'))
        except Exception:
            self.debug("%s: tracking debconf key dell-oobe/tracking unavailable, defaulting to true." % NAME)
            enable = True

        #We don't currently copy dell-oobe debconf keys, so we need to double check /proc/cmdline
        #cleanup when we are done too
        if enable:
            with open('/proc/cmdline', 'r') as cmdline:
                cmd = cmdline.readline().strip().split()
            for option in cmd:
                if 'dell-oobe/tracking=' in option:
                    enable = create_bool(option.split('=')[1])
                    #remove it from the grub default command line now
                    with open('/etc/default/grub','r') as rfd:
                        lines = rfd.readlines()
                    with open('/etc/default/grub','w') as wfd:
                        for line in lines:
                            if line.startswith('GRUB_CMDLINE_LINUX_DEFAULT="'):
                                line = line.replace(option,'')
                            wfd.write(line)
                    subprocess.call('update-grub')

        #disable as necessary
        if not enable:
            self.debug("%s: Disabling tracking source per dell-oobe/tracking.")
            return InstallPlugin.install(self, target, progress, *args, **kwargs)

        #Calculate a sha1sum of the service tag
        try:
            with open('/sys/class/dmi/id/product_serial', 'r') as rfd:
                serial_hash = hashlib.sha1(rfd.readline().lower().strip()).hexdigest() + '.'
        except IOError:
            self.debug("%s: error reading service tag. aborting." % NAME)
            return InstallPlugin.install(self, target, progress, *args, **kwargs)

        #figure out the LOB we have
        with open('/sys/class/dmi/id/product_name','r') as rfd:
            dmi = rfd.readline().lower().strip().split()

        #Check 2 words, 1 word, fall back to default
        check = []
        if len(dmi) > 1:
            check.append("%s %s" % (dmi[0], dmi[1]))
        check.append("%s" %  dmi[0])

        #calculate LOB to add
        selected_lob = ''
        for lob in check:
            if POSSIBLE_LOB.has_key(lob):
                selected_lob = POSSIBLE_LOB[lob] + '.'
                self.debug("%s: Matched system LOB %s to source LOB %s" % (NAME,lob,selected_lob))
                break

        source = serial_hash + selected_lob + 'dell.archive.canonical.com'

        self.write_source(source)

        self.enable_upgrades(source)

        if os.path.exists(KEYRING):
            self.debug("%s: Adding apt-keyring %s" % (NAME, KEYRING))
            subprocess.call(['apt-key', 'add', KEYRING])

if __name__ == '__main__':
    os.environ['UBIQUITY_OEM_USER_CONFIG'] = '1'
    install = Install(None, None)
    install.install( __name__, None)
