
var YahooExtConfig={mName:"ytoolbar",mProgID:"@yahoo.com"};