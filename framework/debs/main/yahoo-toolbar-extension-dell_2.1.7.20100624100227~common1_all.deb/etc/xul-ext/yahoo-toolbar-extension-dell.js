// Place your preferences for yahoo-toolbar-extension-dell in this file.
// You can override here the preferences specified in
// /usr/share/xul-ext/yahoo-toolbar-extension-dell/defaults/preferences/yahoo.js
// /usr/share/xul-ext/yahoo-toolbar-extension-dell/defaults/preferences/Lightening.js
