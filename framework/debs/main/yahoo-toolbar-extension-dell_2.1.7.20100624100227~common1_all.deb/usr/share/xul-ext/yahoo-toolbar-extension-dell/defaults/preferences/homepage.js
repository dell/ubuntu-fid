pref("browser.startup.homepage", "file:/usr/share/xul-ext/yahoo-toolbar-extension-dell/defaults/preferences/homepage.properties");
